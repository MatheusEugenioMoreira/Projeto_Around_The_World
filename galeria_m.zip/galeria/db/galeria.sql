SELECT * FROM galeria.usuario;

insert into galeria.usuario (usuario, email, senha, foto) values ('matheus', 'm@m.com', '123456', '');
insert into galeria.usuario (usuario, email, senha, foto) values ('matheus', 'matheus@gmail.com', 'matheus2020', '');
