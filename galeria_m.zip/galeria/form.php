<?php
if (isset($_SESSION['msg'])) {
echo $_SESSION['msg'];
unset($_SESSION['msg']);
}
?>
<div class="card-body" id="checkboxFotos">
            <form action="./upload.php" method="post"
                    enctype="multipart/form-data">
                <div class="col-6">
                    <input type="radio" name="pasta" value="egito" >
                    Egito
                    <br>
                    <input type="radio" name="pasta" value="eua"> Estados
                    Unidos
                    <br>
                    <input type="radio" name="pasta" value="europa"> Europa
                    <br><br>
                    
                </div>
            </form>
        </div>
    </div>
</div>

<div class="col-md-4">
<form action="./upload.php" method="post" enctype="multipart/form-data">

Selecionar imagem para carregar:

<br><br>
<input type="file" style="margin-left: 15px"  name="foto" id="foto">
<br><br><br><br>
<input type="submit" value="Upload de fotos" style="margin-left: 15px" name="submit">
</form>
</div>







<!--
    php
if ( isset($_SESSION['msg'])){
    echo $_SESSION['msg'];
    unset($_SESSION['msg']);
}
?>
<form action="./upload.php" method="post" enctype="multipart/form-data">

    <br>
    Selecionar imagem para carregar:
    <input type="file" name="foto" id="foto">
    <input type="submit" value="Upload Image" name="submit">
</form>
-->