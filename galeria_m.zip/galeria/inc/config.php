<?php
Session_start();
Header("Content-Type: text/html; charset=utf8");

Define("SERVIDOR", "mysql:host=localhost;dbname=galeria;charset=utf8");
Define("USUARIO", "root");
Define("SENHA", "");