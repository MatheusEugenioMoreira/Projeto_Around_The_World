<?php
require_once "../inc/config.php";

// procura o usuario no banco de dados
//ERRO PDO
$con = new PDO(SERVIDOR, USUARIO, SENHA);
$sql = $con->prepare("SELECT * FROM usuario WHERE email=? AND senha=?");
$sql->execute( array($_POST['email'], ($_POST['senha']) ) );

// devolve o registro do usuário procurado
$row = $sql->fetchObject();

// se o usuário foi localizado
if ($row){
    $_SESSION['usuario'] = $row;
    header("Location: ../");

// se o usuário não foi localizado
}else{
    $_SESSION['msg'] = " <div class='alert alert-danger'>  <strong>Ops!</strong> Acesso negado   </div>";
    header("Location: ../login");
}
?>