<?php

session_start();

unset($_SESSION['usuario']);

$_SESSION['msg'] = "<div class='alert alert-success'>Sessão Encerrada</div>";

header("Location:./");

